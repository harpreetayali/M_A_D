import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText editText = findViewById(R.id.editText);
        final Button btnCalculate = findViewById(R.id.btnCalculate);
        final TextView tvResult = findViewById(R.id.tvResult);

        btnCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String expression = editText.getText().toString();

                try {
                    // Evaluate the expression
                    double result = evaluateExpression(expression);
                    tvResult.setText("Result: " + result);
                } catch (Exception e) {
                    // Handle invalid expressions
                    tvResult.setText("Invalid expression");
                }
            }
        });
    }

    private double evaluateExpression(String expression) {
        // You can use a library or write your logic to evaluate the expression here.
        // For simplicity, let's assume a basic implementation for addition, subtraction, multiplication, and division.
        String[] tokens = expression.split(" ");
        double operand1 = Double.parseDouble(tokens[0]);
        double operand2 = Double.parseDouble(tokens[2]);
        double result = 0;

        switch (tokens[1]) {
            case "+":
                result = operand1 + operand2;
                break;
            case "-":
                result = operand1 - operand2;
                break;
            case "*":
                result = operand1 * operand2;
                break;
            case "/":
                result = operand1 / operand2;
                break;
        }

        return result;
    }
}